from flask import Blueprint, request
from services.taskManager import TaskManager

task_bp = Blueprint('task_routes', __name__)
tm = TaskManager()                  

# --- CREATE ---
@task_bp.route('/', methods=['POST'])
def create_task():
    data = request.get_json()
    tm.create_task(
        data["task_id"], data["title"], data["description"],
        data["due_date"], data["priority"], data["user_id"]
    )
    return {"message": "Task created"}, 201

# --- READ ALL ---
@task_bp.route('/', methods=['GET'])
def list_tasks():
    return [t.to_dict() for t in tm.get_all_tasks()], 200

# --- READ ONE ---
@task_bp.route('/<int:task_id>', methods=['GET'])
def get_task(task_id):
    task = tm.get_task(task_id)
    if not task:
        return {"error": "Task not found"}, 404
    return task.to_dict(), 200

# --- UPDATE STATUS ---
@task_bp.route('/<int:task_id>/status', methods=['PUT'])
def update_status(task_id):
    data = request.get_json()
    tm.update_task_status(task_id, data["status"])
    return {"message": "Status updated"}, 200

# --- UPDATE PRIORITY ---
@task_bp.route('/<int:task_id>/priority', methods=['PUT'])
def update_priority(task_id):
    data = request.get_json()
    tm.update_task_priority(task_id, data["priority"])
    return {"message": "Priority updated"}, 200

# --- DELETE ---
@task_bp.route('/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    tm.delete_task(task_id)
    return {"message": "Task deleted"}, 200
