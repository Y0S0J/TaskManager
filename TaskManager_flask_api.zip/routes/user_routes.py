from flask import Blueprint, request
from services.taskManager import TaskManager

user_bp = Blueprint('user_routes', __name__)
tm = TaskManager()                

# --- CREATE ---
@user_bp.route('/', methods=['POST'])
def create_user():
    data = request.get_json()
    tm.create_user(data["user_id"], data["name"], data["email"])
    return {"message": "User created"}, 201           

# --- READ ALL ---
@user_bp.route('/', methods=['GET'])
def list_users():
    return [u.to_dict() for u in tm.get_all_users()], 200

# --- READ ONE ---
@user_bp.route('/<int:user_id>', methods=['GET'])
def get_user(user_id):
    user = tm.get_user(user_id)
    if not user:
        return {"error": "User not found"}, 404
    return user.to_dict(), 200

# --- DELETE ---
@user_bp.route('/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    tm.delete_user(user_id)
    return {"message": "User deleted"}, 200
