from flask import Flask
from routes.user_routes import user_bp
from routes.task_routes import task_bp


app = Flask(__name__)

app.register_blueprint(user_bp, url_prefix='/users')
app.register_blueprint(task_bp, url_prefix='/tasks')

@app.route('/')
def home():
    return {"message": "TaskManager API is running"}, 200

if __name__ == '__main__':
    app.run(debug=True)

