from db.connector import get_db_connection
from models.user import User
from models.tasks import Task

class TaskManager:
    def __init__(self):
        self.conn = get_db_connection()
        self.users = {}
        self.tasks = {}
        self._load_users_from_db()
        self._load_tasks_from_db() 

    def _load_users_from_db(self):
        with self.conn.cursor(dictionary=True) as cur:
            cur.execute("SELECT * FROM users")
            for row in cur.fetchall():
                user = User(row["user_id"], row["name"], row["email"])
                self.users[user.user_id] = user

    def _load_tasks_from_db(self):
        with self.conn.cursor(dictionary=True) as cur:
            cur.execute("SELECT * FROM tasks")
            for row in cur.fetchall():
                task = Task(
                    row["task_id"], row["title"], row["description"],
                    row["due_date"],
                    priority=Task._REVERSE_PRIORITY.get(row["priority"], "Medium"),
                    status=row["status"]
                )
                if row["user_id"] in self.users:
                    user = self.users[row["user_id"]]
                    task.assign_to(user)
                    user.add_task(task)
                self.tasks[task.task_id] = task

    # ----------- User Operations -----------
    def create_user(self, user_id, name, email):
        if user_id in self.users:
            raise ValueError("User ID already exists.")

        user = User(user_id, name, email)
        self.users[user_id] = user

        with self.conn.cursor() as cur:
            cur.execute("INSERT INTO users (user_id, name, email) VALUES (%s, %s, %s)",
                        (user_id, name, email))
            self.conn.commit()

    def get_all_users(self):
        return list(self.users.values())

    def get_user(self, user_id):
        return self.users.get(user_id)

    def delete_user(self, user_id):
        if user_id not in self.users:
            raise ValueError("User not found.")
        with self.conn.cursor() as cur:
            cur.execute("DELETE FROM users WHERE user_id = %s", (user_id,))
            self.conn.commit()
        del self.users[user_id]

    # ----------- Task Operations -----------
    def create_task(self, task_id, title, description, due_date, priority, user_id):
        if task_id in self.tasks:
            raise ValueError("Task ID already exists.")

        task = Task(task_id, title, description, due_date, priority)
        self.tasks[task_id] = task

        user = self.users.get(user_id)
        if user:
            task.assign_to(user)
            user.add_task(task)

        with self.conn.cursor() as cur:
            cur.execute(
                """INSERT INTO tasks 
                   (task_id, title, description, status, priority, user_id, due_date)
                   VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                (
                    task.task_id, task.title, task.description,
                    task.status, task.priority_as_int(), user_id, task.due_date
                )
            )
            self.conn.commit()

    def get_all_tasks(self):
        return list(self.tasks.values())

    def get_task(self, task_id):
        return self.tasks.get(task_id)

    def update_task_status(self, task_id, new_status):
        task = self.get_task(task_id)
        if not task:
            raise ValueError("Task not found.")
        task.update_status(new_status)
        with self.conn.cursor() as cur:
            cur.execute("UPDATE tasks SET status = %s WHERE task_id = %s",
                        (task.status, task_id))
            self.conn.commit()

    def update_task_priority(self, task_id, new_priority):
        task = self.get_task(task_id)
        if not task:
            raise ValueError("Task not found.")
        task.update_priority(new_priority)
        with self.conn.cursor() as cur:
            cur.execute("UPDATE tasks SET priority = %s WHERE task_id = %s",
                        (task.priority_as_int(), task_id))
            self.conn.commit()

    def delete_task(self, task_id):
        if task_id not in self.tasks:
            raise ValueError("Task not found.")
        with self.conn.cursor() as cur:
            cur.execute("DELETE FROM tasks WHERE task_id = %s", (task_id,))
            self.conn.commit()
        del self.tasks[task_id]

    def close(self):
        self.conn.close()
